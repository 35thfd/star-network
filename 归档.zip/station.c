#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <queue>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>


void send_response(int sockfd, const char* message, struct sockaddr_in client_addr) {
    sendto(sockfd, message, strlen(message), MSG_CONFIRM, (const struct sockaddr *)&client_addr, sizeof(client_addr));
    printf("Sent response to %s\n", inet_ntoa(client_addr.sin_addr));
}

void* process_message(void *arg) {
    ProcessData *data = (ProcessData*)arg;
    char *message = data->message;
    int sockfd = data->sockfd;
    struct sockaddr_in client_addr = data->client_addr;
        
    int missing[CNT];
    if (station->queue.size() < station->cnt) {
        station->init_queue();
    }

    for(int i = 0 ; i < CNT ; i ++)
    {
        uint8_t temp = (uint8_t)message[i];
        missing[i] = temp;
    }

    int send_data = station->check(&missing, CNT);
    if (send_data != -1) {
        char* data = packet[send_data];
        send_response(sockfd, data, client_addr);
    }
        
    return NULL;
}
