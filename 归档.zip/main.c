#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <queue>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "station.h"
#include "satellite.h"

#define CNT 10  // 数据块总数
#define PORT 12345  
#define MAX_SATELLITES 100  
#define MAX_BLOCK 256

char packet[MAX_BLOCK];

typedef struct {
    char *message;
    int sockfd;
    struct sockaddr_in client_addr;
} ProcessData;

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    Station* station;

    if (station->setup_and_listen(&sockfd, &server_addr) < 0) {
        fprintf(stderr, "Failed to setup and listen\n");
        return EXIT_FAILURE;
    }
    station.sockfd = sockfd;

    char buffer[BUFFER_SIZE];
    struct sockaddr_in client_addr;
    socklen_t addr_len = sizeof(client_addr);

    while (1) {
        int n = recvfrom(sockfd, (char *)buffer, BUFFER_SIZE, MSG_WAITALL, (struct sockaddr *)&client_addr, &addr_len);
        if (n < 0) {
            perror("recvfrom failed");
            continue;
        }
        buffer[n] = '\0';
        printf("Base Station: Received Message from Satellite: %s\n", buffer);

        pthread_t process_thread;
        ProcessData *data = malloc(sizeof(ProcessData));
        data->message = strdup(buffer); // 复制消息内容
        data->sockfd = sockfd;
        data->client_addr = client_addr;

        if (pthread_create(&process_thread, NULL, process_message, (void*)data) != 0) {
            perror("Failed to create process thread");
            free(data->message);
            free(data);
            continue;
        }

        // 分离线程，让其自行管理生命周期
        pthread_detach(process_thread);
    }

    close(sockfd);
    return 0;
}



